require 'test_helper'

class PieceSetHelperTest < ActionView::TestCase
end
