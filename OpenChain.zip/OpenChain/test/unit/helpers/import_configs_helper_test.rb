require 'test_helper'

class ImportConfigsHelperTest < ActionView::TestCase
end
