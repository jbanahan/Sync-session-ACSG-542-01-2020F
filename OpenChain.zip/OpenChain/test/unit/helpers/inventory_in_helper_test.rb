require 'test_helper'

class InventoryInHelperTest < ActionView::TestCase
end
