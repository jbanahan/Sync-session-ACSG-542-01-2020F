require 'test_helper'

class DivisionsHelperTest < ActionView::TestCase
end
