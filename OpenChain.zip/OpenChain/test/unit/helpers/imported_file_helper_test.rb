require 'test_helper'

class ImportedFileHelperTest < ActionView::TestCase
end
