require 'test_helper'

class ItemChangeSubscriptionHelperTest < ActionView::TestCase
end
