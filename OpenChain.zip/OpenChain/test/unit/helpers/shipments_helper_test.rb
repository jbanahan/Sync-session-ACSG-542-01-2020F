require 'test_helper'

class ShipmentsHelperTest < ActionView::TestCase
end
