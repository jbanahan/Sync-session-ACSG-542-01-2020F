class Location < ActiveRecord::Base


end
