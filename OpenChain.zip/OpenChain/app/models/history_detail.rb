class HistoryDetail < ActiveRecord::Base
  belongs_to :history
end
