class Country < ActiveRecord::Base
	has_many :addresses
end
