# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
OpenChain::Application.config.secret_token = '70edff8b06f8ee0acdbdf5ef7f2784059044ad6419dbe99618ee5d03cda6b31c374b606d1243b8dbc7fad8c3a79e9366efe67ceee1af23f06e1212e8d19cc8aa'
